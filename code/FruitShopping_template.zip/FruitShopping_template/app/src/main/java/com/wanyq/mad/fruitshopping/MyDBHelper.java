package com.wanyq.mad.fruitshopping;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

public class MyDBHelper extends SQLiteOpenHelper {
    /*
    工具类，用于数据库表的创建和必要的更新。
     */
    public MyDBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);

        Log.i("Sqlite", " 数据库工具类 init");
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // todo： 创建数据库中的一个表；

        Log.i("Sqlite", "create table ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // todo: 有需要的时候更新表定义；
//        String sql = "alter table alter column id integer auto_increment";
//        String sql = "alter table  contact add column address text ";
        Log.i("SQLite", "onUpgrade");

    }
}
