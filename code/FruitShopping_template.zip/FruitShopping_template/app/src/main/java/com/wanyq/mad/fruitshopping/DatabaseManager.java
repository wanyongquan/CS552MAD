package com.wanyq.mad.fruitshopping;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;



import java.util.ArrayList;
import java.util.List;


/**
 * Created by wanyongquan on 2018-12-09.
 * 数据库访问对象，提供数据库增、删、改、查接口；
 */

public class DatabaseManager {
    private static final int DB_VERSION = 3;
    // todo : 定义数据库和表名称；
    private static final String DB_NAME= " ";
    public static final String TABLE_NAME =" ";


    private SQLiteDatabase sqliteDb;
    private MyDBHelper sqliteHelper;

    public DatabaseManager(Context context){
        // 如果数据库不存在，则 创建一个名字为 DB_NAME 的 数据库. 如果数据库存在，则打开该数据库。
        sqliteHelper = new MyDBHelper(context, DB_NAME, null, DB_VERSION);

    }

    public void insert(Fruit fruit){
        sqliteDb = sqliteHelper.getWritableDatabase();
        /*
        第一种方式： 直接写SQL语句， 并调用.execSQL()方法；
         */
        String sql = “   ”;

        sqliteDb.execSQL(sql);
        Log.d("db", "insert success");
        sqliteDb.close();
    }


    public int delete(int id){

    }


    public void updateProduct(int id, String name, String chandi){
        sqliteDb = sqliteHelper.getWritableDatabase();
        String sql = “   ”;
        sqliteDb.close();
    }


    // 查询并返回所有记录；
    public List<Fruit> findAllFruits(){
        sqliteDb = sqliteHelper.getReadableDatabase();
        String sql = ;
        Cursor cursor = sqliteDb.rawQuery(sql, null);  // 获取游标，用于遍历返回的数据
        List<Fruit> items = new ArrayList<Fruit>();
        while (cursor.moveToNext()){
            int id = ;
            String name = ;
            String chandi = ;
//            items.add( name );
            Fruit temp = new Fruit(id, name, chandi);
//            items.add(temp.toString());
            items.add(temp);
        }
        Log.d("db", "get all records");
        cursor.close(); // 关闭游标
        sqliteDb.close();
        return items;
    }

    // 根据名称查询，并返回记录
    public List<String> findNamesByName(String name){
        sqliteDb = sqliteHelper.getReadableDatabase();
        Log.i("SQL",String.valueOf(sqliteDb.getVersion()));
        String sql = "  ";
        Cursor cursor = sqliteDb.rawQuery(sql, null);  // 获取游标，用于遍历返回的数据

        Log.d("db", "find  records");
        cursor.close(); // 关闭游标
        sqliteDb.close();
        return items;
    }
}

