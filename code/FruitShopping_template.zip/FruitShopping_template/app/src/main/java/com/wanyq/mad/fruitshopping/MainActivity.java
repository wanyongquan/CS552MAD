package com.wanyq.mad.fruitshopping;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btn_add, btn_query, btn_update, btn_delete;
    EditText edit_id, edit_name, edit_tel;
    ListView ls_contact;

    List<Fruit> dataList ;
    ArrayAdapter<Fruit> adapter;
    DatabaseManager dbMgr;

    private static String TAG = "Main";

    private int selected_item_id ;
    private String selected_item_name ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        MyDBHelper dbHelper = new MyDBHelper(MainActivity.this, "contact2.db", null, 1);
//        SQLiteDatabase db = dbHelper.getReadableDatabase();



        ls_contact = findViewById(R.id.listView_contacts);

        dbMgr = new DatabaseManager(MainActivity.this);
        dataList = dbMgr.findAllFruits();
        adapter = new ArrayAdapter<Fruit>(MainActivity.this, android.R.layout.simple_list_item_single_choice, dataList);
        ls_contact.setAdapter(adapter);

        ls_contact.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int id2 =  adapter.getItem(position).getId();
                Fruit selectedItem = (Fruit)adapter.getItem(position);
                Log.d(MainActivity.TAG, selectedItem.getName());
                Log.d(MainActivity.TAG, String.valueOf(id2));

                   // todo : 读取当前选中的记录，把相应对象的属性设置到 EditText中显示；

            }
        });
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // todo: 打开新增Activity


            }
        });

        btn_query.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name =edit_name.getText().toString().trim();

                dataList.clear();
//                dataList.addAll(dbMgr.findNamesByName(name));
                dataList.addAll( dbMgr.findAllFruits() );
                adapter.notifyDataSetChanged();
                Log.i(MainActivity.TAG, "query clicked and load data");
            }
        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name =;
                String chandi = ;
                if (TextUtils.isEmpty(name)  || TextUtils.isEmpty(chandi)){
                    // todo: toast 信息
                    Toast.....show();
                }
                else {
                    dbMgr.updateProduct(selected_item_id, name, chandi);

                    refreshListView();
                }
            }
        });
        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Warning");
                // todo : 设置AlertDialog

                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.i("result", "delete  YES  button");

                        dbMgr.delete(Integer.valueOf(selected_item_id));
                       // todo: EditText 置空；
                        refreshListView();
                        Log.i("result", "delete success");
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //
                    }
                });
               // todo: 显示 dialog

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        Log.i(this.TAG, "onResume");

        refreshListView();
    }

    private void refreshListView(){
        dataList.clear();
        dataList.addAll( dbMgr.findAllFruits() );
        adapter.notifyDataSetChanged();
    }
}