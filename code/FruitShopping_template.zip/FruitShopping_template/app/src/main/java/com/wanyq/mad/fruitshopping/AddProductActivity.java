package com.wanyq.mad.fruitshopping;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddProductActivity extends AppCompatActivity {
    EditText edtName, edtChandi;
    Button btnSave, btnClose ;

    DatabaseManager dbMgr = new DatabaseManager(AddProductActivity.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        edtName = findViewById(R.id.editText_product_name);
        edtChandi = findViewById(R.id.editText_chandi);

        btnSave = findViewById(R.id.button_save);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ;
                String chandi = ;

                Fruit fruit = new Fruit( name, chandi);
                dbMgr.insert(fruit);

                Log.i("Insert", "insert a row");
            }
        });

        btnClose = findViewById(R.id.button_close);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(AddProductActivity.this, MainActivity.class);
//                startActivity(intent);
                finish();
            }
        });
    }
}