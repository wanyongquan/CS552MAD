package com.wanyq.mad.fruitshopping;
/**
 * Created by wanyongquan on 2018-12-09.
 *  一个Java类，表示数据库中要记录的数据；
 */
public class Fruit {

    private int id;
    private String name;
    private String chandi;

    public Fruit(int stuno, String name, String chandi)
    {
        this.id = stuno;
        // todo: 构造函数；
    }

    public Fruit(String name, String chandi){
        // todo: 构造函数；

    }
    @Override
    public String toString(){

        return "[编号：" + this.getId() + "]";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    // todo: 定义其他必要的属性和 getter， setter 函数；
}
