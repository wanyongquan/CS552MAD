package com.wanyq.mad.advancelistview;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ActivityDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = getIntent();
        String fruit_name = intent.getStringExtra("fruit");

        TextView tv_name = findViewById(R.id.textView);
        tv_name.setText(fruit_name);

        ImageView iv = findViewById(R.id.imageView);
        if (fruit_name.equals("苹果")){
           iv.setImageResource(R.drawable.apple_pic);
        }
    }
}