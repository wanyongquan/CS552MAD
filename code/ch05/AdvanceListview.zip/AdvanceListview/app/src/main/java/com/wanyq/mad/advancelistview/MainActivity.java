package com.wanyq.mad.advancelistview;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.wanyq.mad.advancelistview.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String[] title = new String[]{"苹果","香蕉","樱桃","葡萄","芒果","梨","菠萝","草莓"};
    int[] image = new int[]{R.drawable.apple_pic, R.drawable.banana_pic, R.drawable.cherry_pic,
                            R.drawable.grape_pic, R.drawable.mango_pic, R.drawable.pear_pic,
                            R.drawable.pineapple_pic, R.drawable.strawberry_pic};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView)findViewById(R.id.list_View);
        List<Map<String, Object>> dataList = new ArrayList<>();
        for(int i = 0; i< title.length;i++){
            Map<String, Object> map = new HashMap<>();
            map.put("title", title[i]);
            map.put("image", image[i]);
            dataList.add(map);
        }
        SimpleAdapter adapter = new SimpleAdapter(this, dataList,
                        R.layout.fruit_item,
                        new String[]{"title", "image"},
                        new int[]{R.id.fruit_name, R.id.fruit_image});

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//                Toast.makeText(MainActivity.this, title[position],
//                            Toast.LENGTH_LONG).show();
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("comfirm");
                builder.setMessage("你确定要查看这个水果吗？");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(MainActivity.this, ActivityDetail.class);
                        intent.putExtra("fruit_name", title[position]);
                        startActivity(intent);
                    }
                });
                builder.setCancelable(true);
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Log.i("EventClick", "No clicked");
                    }
                });
                builder.show();
            }
        });
    }
}
