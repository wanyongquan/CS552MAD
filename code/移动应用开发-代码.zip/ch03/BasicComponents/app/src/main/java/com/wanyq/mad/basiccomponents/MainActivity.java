package com.wanyq.mad.basiccomponents;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends Activity {
    EditText edit_username;
    CheckBox chk_op1;
    RadioButton radio_btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // 泛型
         edit_username =  findViewById(R.id.edt_Username);
        //System.out.println(edit_username.getText().toString());

        Log.i("event", edit_username.getText().toString());
        EditText edit_pwd = (EditText)findViewById(R.id.edt_Password);
        //System.out.println(edit_pwd.getText().toString());
        Log.i("event", edit_pwd.getText().toString());
        // Button btn_ok = (Button)findViewById(R.id.button_ok);
        chk_op1 = (CheckBox)findViewById(R.id.checkBox);
        radio_btn1 = findViewById(R.id.radioButton);
    }

    public void sendMsg(View view){
//        EditText edit_username = (EditText) findViewById(R.id.edt_Username);
//        System.out.println(edit_username.getText().toString());
        Log.i("event", edit_username.getText().toString());
//
        String s = null;
        if (chk_op1.isChecked() ){
            s = "足球 checked";
        }
        else{
            s="none";
        }
        Log.i("event", s);
//
        String s2 = null;
        if (radio_btn1.isChecked() ){
            s2 = "radio1 checked";
        }
        else{
            s2="radio1 none";
        }
        Log.i("event", s2);

    }
}