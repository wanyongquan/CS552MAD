package com.wanyq.mad.advancedcomponents;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Intent intent = getIntent();
        ListView lvdata = (ListView) findViewById(R.id.lvdata);
        List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_credit_card_black_24dp);
        map.put("text", intent.getStringExtra("stuno"));
        list.add(map);

        map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_account_box_black_24dp);
        map.put("text", intent.getStringExtra("stuname"));
        list.add(map);

        map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_wc_black_24dp);
        map.put("text", intent.getStringExtra("gender"));
        list.add(map);

        map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_account_balance_black_24dp);
        map.put("text", intent.getStringExtra("college"));
        list.add(map);

        map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_school_black_24dp);
        map.put("text", intent.getStringExtra("major"));
        list.add(map);

        map = new HashMap<String, Object>();
        map.put("img", R.drawable.ic_assignment_ind_black_24dp);
        map.put("text", intent.getStringExtra("class"));
        list.add(map);
        SimpleAdapter simpleAdapter = new SimpleAdapter(Main2Activity.this, list, R.layout.item, new String[]{"img", "text"}, new int[]{R.id.img, R.id.tvtext});
        lvdata.setAdapter(simpleAdapter);
    }
}
