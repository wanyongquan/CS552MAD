package com.wanyq.mad.networkaccess;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class JSONActivity extends AppCompatActivity {
    private static String TAG = "APPLog";
    TextView textView = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json);

        textView = findViewById(R.id.textView);

        Button sendRequest = (Button) findViewById(R.id.send_request);
        sendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendRequestWithHttpURLConnection();
            }
        });

        Button btn_forecast = (Button) findViewById(R.id.button_forecast);
        btn_forecast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendRequestWithHttpURLConnection2();

            }
        });
    }


    private void sendRequestWithHttpURLConnection(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
                      URL url = new URL("https://raw.githubusercontent.com/wanyongquan/CS552MAD/main/code/employees.json");
//                    URL url = new URL("http://t.weather.itboy.net/api/weather/city/101020100");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    if( connection.getResponseCode() == 200) {
                        InputStream in = connection.getInputStream();
                        // 下面对获取到的输入流进行读取
                        reader = new BufferedReader(new InputStreamReader(in));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);

                        }
                        parseJSON1(response.toString());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }

    private void sendRequestWithHttpURLConnection2(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection connection = null;
                BufferedReader reader = null;
                try {
//                      URL url = new URL("http://api.qingyunke.com/api.php?key=free&appid=0&msg=上海天气");
                    URL url = new URL("http://t.weather.itboy.net/api/weather/city/101020100");
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(8000);
                    connection.setReadTimeout(8000);
                    if( connection.getResponseCode() == 200) {
                        InputStream in = connection.getInputStream();
                        // 下面对获取到的输入流进行读取
                        reader = new BufferedReader(new InputStreamReader(in));
                        StringBuilder response = new StringBuilder();
                        String line;
                        while ((line = reader.readLine()) != null) {
                            response.append(line);

                        }
                        parseJSON2(response.toString());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (reader != null) {
                        try {
                            reader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }
        }).start();
    }

    /*
    解析天气JSON数据
     */
    private void parseJSON1(String jsonData) {
        try {
            JSONObject jsonObject = new JSONObject(jsonData);

//                String result = jsonObject.getString("result");
//                String content = jsonObject.getString("content");
            
                String employee_data = jsonObject.getString("employees");
                JSONArray employee_arr = new JSONArray(employee_data);
                StringBuilder sb_employee = new StringBuilder();
                String first_name= null;
                String last_name=null;
                for (int i =0; i< employee_arr.length();i++ ) {
                    JSONObject employee = employee_arr.getJSONObject(i);
                     first_name = employee.getString("firstName");
                     last_name = employee.getString("lastName");
                    sb_employee.append("firstName: " + first_name + " lastName: " + last_name + "\n");
                    Log.i("result", "firstName: " + first_name + " lastName: " + last_name);
                }



            runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        textView.setText("");
                        textView.append(sb_employee.toString());
                    }
                });


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
    解析复杂天气信息JSON
     */
    private void parseJSON2(String jsonData) {
        try {
            JSONObject jsonObject = new JSONObject(jsonData);

            String date = jsonObject.getString("date");
            StringBuilder weather = new StringBuilder();
            weather.append("日期：   "+ date+ "\n" );

            String cityInfo = jsonObject.getString("cityInfo");
            JSONObject cityinfoObj = new JSONObject(cityInfo);
            String city = cityinfoObj.getString("city");
            weather.append("城市： "+city +'\n');
            String data = jsonObject.getString("data");
            JSONObject dataObj = new JSONObject(data);
            // todo：解析温度、湿度


            //todo: 结项json数组

            for (int i =0; i< forcast_arr.length(); i++) {
                //todo: 解析json

                Log.d(JSONActivity.TAG, "预报日期：" + next_date);
                Log.d(TAG, "日期：   \n " + next_date);
                Log.d(TAG, "高温     " + high);
                Log.d(TAG,"week     \n" + week);
                weather.append(String.format("%s | %s | %s\n", next_date, high, week));

            }

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textView.setText("");
                    textView.append(weather.toString());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }





}
