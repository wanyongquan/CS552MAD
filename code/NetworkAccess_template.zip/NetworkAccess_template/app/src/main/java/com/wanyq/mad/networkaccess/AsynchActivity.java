package com.wanyq.mad.networkaccess;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Timer;

public class AsynchActivity extends AppCompatActivity {

    Button btn_send, btn_send2, btn_sync = null;
    TextView txt_description = null;
    Handler handler=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_asynch);

        txt_description = findViewById(R.id.textView);
        btn_send = findViewById(R.id.button_send);
        btn_send2 = findViewById(R.id.button_send2);
        btn_sync = findViewById(R.id.button_sync);

        handler = new Handler(Looper.getMainLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
                super.handleMessage(msg);

                switch (msg.what ){
                    case  0x123:
                        String txt = (String) msg.obj;
                        txt_description.setText(txt);
                        break;
                    case 0x120:
                        int code  = (int)msg.obj;
                        txt_description.setText(String.valueOf(code));
                }



            }
        };

        btn_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        // 模拟启动异步线程，
                        try {
                            Thread.sleep(10000);

                            //发送消息
                            Message msg = new Message();
                            msg.what = 0x123;
                            msg.obj = "Any data need to update on UI ";

                            handler.sendMessage(msg);

                        } catch (Exception e) {
                            Log.e("Error", e.getMessage());
                        }
                    }
                }).start();

            }
        });

        btn_send2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动异步线程，发送消息；
                Message msg = new Message();
                msg.what = 0x120;
                msg.obj = 5438;
//                handler.sendEmptyMessage(0x123);
                handler.sendMessage(msg);
            }
        });

        btn_sync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Thread.sleep(10000);
                    txt_description.setText("同步操作完成");
                }
                catch (Exception e){
                    Log.e("Error", e.getMessage());
                }

            }
        });
    }
}