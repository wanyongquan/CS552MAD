package com.wanyq.mad.networkaccess;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button btnStartWebView ;
    Button btnHttp, btn_img, btn_asynch, btn_json;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStartWebView = (Button)findViewById(R.id.button_startwebview);
        btnStartWebView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, WebViewer.class);
                startActivity(intent);
            }
        });


        btnHttp = (Button)findViewById(R.id.button_http);
        btnHttp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, HTTPActivity.class);
                startActivity(intent);
            }
        });

        btn_img = (Button)findViewById(R.id.button_img);
        btn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ImageViewer.class);
                startActivity(intent);
            }
        });

        btn_asynch = (Button)findViewById(R.id.button_asynch);
        btn_asynch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AsynchActivity.class);
                startActivity(intent);
            }
        });

        btn_json = (Button)findViewById(R.id.button_json);
        btn_json.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, JSONActivity.class);
                startActivity(intent);
            }
        });

    }
}