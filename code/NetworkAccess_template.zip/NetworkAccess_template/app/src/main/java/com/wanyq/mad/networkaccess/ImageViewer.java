package com.wanyq.mad.networkaccess;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ImageViewer extends AppCompatActivity {

    ImageView imgViewer = null;
    EditText txt_url = null;
    Button btn_view = null;
    Handler handler = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_viewer);

        imgViewer = findViewById(R.id.imageView);
        txt_url = findViewById(R.id.editText_imgurl);
        btn_view = findViewById(R.id.button_load);
        btn_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url_path = txt_url.getText().toString().trim();

                new Thread(){
                    HttpURLConnection conn = null;
                    @Override
                    public void run() {
//                        super.run();
                        try {
                            URL url = new URL(url_path);
                            conn = (HttpURLConnection)url.openConnection();
                            conn.setRequestMethod("GET");
                            conn.setReadTimeout(5000);

                            int response = conn.getResponseCode();
                            Log.i("Result", "respone: " +  String.valueOf(response));
                            Message msg = new Message();
                            if (response == 200){
                                InputStream is = conn.getInputStream();
                                Bitmap image = BitmapFactory.decodeStream(is);
                                msg.what = 1;
                                msg.obj = image;
                                handler.sendMessage(msg);
                                Log.i("Result", "send msg");
                            }
                            else  {
                            // add code to handle other response code here
                            }

                        }
                        catch (Exception e){

                        }

                    }
                }.start();
            }
        });

        handler = new Handler(getMainLooper()){
            @Override
            public void handleMessage(@NonNull Message msg) {
//                super.handleMessage(msg);
                if (msg.what ==1 ){
                    Log.i("Result", "Set ImageView");
                    Bitmap bitmap = (Bitmap)msg.obj;
                    imgViewer.setImageBitmap(bitmap);
                }
            }
        };
    }
}